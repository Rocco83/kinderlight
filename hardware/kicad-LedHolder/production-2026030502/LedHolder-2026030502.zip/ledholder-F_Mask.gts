G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*
G04 #@! TF.CreationDate,2026-03-05T12:53:28+01:00*
G04 #@! TF.ProjectId,ledholder,6c656468-6f6c-4646-9572-2e6b69636164,2026030502*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2026-03-05 12:53:28*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X0.250000X1.500000X-0.250000X1.500000X-0.250000X-1.500000X0.250000X-1.500000X0*%
%ADD11RoundRect,0.250001X0.499999X1.449999X-0.499999X1.449999X-0.499999X-1.449999X0.499999X-1.449999X0*%
%ADD12R,1.070000X1.800000*%
%ADD13O,1.070000X1.800000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X111204000Y-73462000D03*
X109204000Y-73462000D03*
X107204000Y-73462000D03*
X105204000Y-73462000D03*
D11*
X113554000Y-67712000D03*
X102854000Y-67712000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,LED1*
X110110000Y-76936600D03*
D13*
X108840000Y-76936600D03*
X107570000Y-76936600D03*
X106300000Y-76936600D03*
G04 #@! TD*
M02*
